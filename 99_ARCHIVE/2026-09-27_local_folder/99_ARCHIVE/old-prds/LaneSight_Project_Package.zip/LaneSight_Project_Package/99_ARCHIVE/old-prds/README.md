# Archived PRDs
Move superseded PRDs here rather than deleting them. The canonical strategy is currently `01_PRODUCT/LaneSight_PRD_Product_Strategy_v3.docx`.
