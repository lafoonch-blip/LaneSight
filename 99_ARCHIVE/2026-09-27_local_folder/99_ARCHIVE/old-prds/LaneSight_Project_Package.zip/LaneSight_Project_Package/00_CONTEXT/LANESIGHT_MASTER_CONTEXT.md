# LaneSight Master Context
Status: CANONICAL  
Version: 1.0  
Last Updated: 2026-09-27

## 1. What LaneSight is
LaneSight is the digital platform for bowlers: a hardware-agnostic bowling intelligence system that combines video, optional sensor telemetry, scoring/league records, equipment history and coaching into one persistent Bowler Profile.

**North star:** become the place where a bowler plays, improves, manages equipment, understands performance, connects with teammates, and eventually manages league participation.

**Tagline:** See More. Bowl Smarter.

## 2. Commercial strategy
Do not launch as an all-in-one league platform. Progressively earn the right to expand:

**Measure → Profile → Coach → Team → Connect → Manage → Platform**

1. Free/low-friction Shot Analyzer creates the first wow moment.
2. Saving results creates a Bowler Profile.
3. Arsenal and sensor fusion deepen personalization.
4. Session/League Mode + Audio Coach create weekly habit.
5. Team Lane Management creates invitations/network effects.
6. Authorized scoring, league and sanctioned data make LaneSight the bowler’s home.
7. Once bowler penetration creates pull, expand into league management and center software.

## 3. Product pillars
- **Profile:** persistent bowling identity, history, records and achievements.
- **Play:** leagues, schedules, scores, tournaments and standings.
- **Perform:** video/sensor shot telemetry and trends.
- **Coach:** execution analysis, lane intelligence, recommendations and Audio Coach.
- **Equipment:** arsenal, drilling/layout, PAP, surface, maintenance and observed performance.
- **Team:** teammates, shared lane map and team lane strategy.

Future branded areas: LaneSight Profile, Live, Coach, Arsenal, Team, Leagues and Centers.

## 4. Foundational technical sequence
1. Stable tripod video + manual calibration.
2. Automatic ball detection/tracking.
3. Sensor integration + shot synchronization.
4. Fixed-camera Session Mode.
5. League Mode with session-scoped user recognition.
6. Multi-shot intelligence.
7. Coaching/recommendation feedback loops.
8. Handheld/shaky video.
9. POV/head-mounted video.
10. Smart-glasses integrations.

## 5. Fixed-camera measurement model
Pipeline: `video → lane geometry → ball detection → tracking → pixel-to-lane mapping → trajectory → metrics`.

Trajectory point: `P_i = (t_i, x_i, y_i)` where x is lateral board and y is feet downlane.

Core outputs when confidence supports them:
- launch board and angle
- arrow board
- speed
- breakpoint board and distance
- entry board and angle
- pin result
- confidence/source

Board convention: Board 1 is right gutter and Board 39 is left gutter looking from foul line toward pins. Handedness is separate.

## 6. Sensor fusion
Sensor support happens early but remains optional. Use a `SensorAdapter` abstraction so no single device becomes a dependency. Normalize speed, RPM, axis rotation, axis tilt, loft, timestamp and confidence when available.

Every measurement retains source and confidence. Overlap such as speed is valuable for validation. The key engineering problem is matching `Sensor Shot N` to `Video Shot N`, initially using event/release timestamps with tolerance.

## 7. Bowler Profile
The profile should increasingly build itself through normal bowling rather than long forms. It can eventually aggregate:
- sanctioned/member records where officially supported
- league/team/schedule/standings data
- scoring-center/session results
- LaneSight shot telemetry
- sensor release telemetry
- arsenal/configuration history
- coaching observations/recommendations/outcomes
- team data with explicit permission

External data always retains provenance, season/context and authority level.

## 8. Arsenal
Distinguish `BallModel` from the user’s physical `UserBall`.

Canonical hierarchy: `Ball Model → User Ball → Configuration History → Surface History → Shot History → Observed Performance`.

Track factory specs plus actual weight, PAP, drilling/layout, pin/PSA/VAL information, finger/thumb setup, current surface, surface products, resurfacing and maintenance. Never overwrite historical configuration.

League/Live UI always has a clear **Current Ball** control. Auto-detection should suggest/confirm switches rather than silently changing unless confidence is exceptionally high.

## 9. League Mode
Phone remains on a tripod while LaneSight watches the pair. Enroll the user for the session (“This is me”) using multi-signal person re-identification: appearance, silhouette, pose/motion, approach path, handedness, ball appearance and optional supporting face signal. Do not depend on permanent facial recognition.

High-confidence user deliveries are analyzed/saved. Low-confidence non-user deliveries are ignored. Uncertain candidates can be held for review. Non-user footage should be discarded quickly and no named profiles/stats should be created for non-enrolled bowlers.

## 10. Audio Coach
Canonical experience: `phone on tripod → League Mode → earbud → bowl → recognize shot → analyze vision + sensor → speak concise feedback before next shot`.

Modes can include Off, Metrics, Coach and Coach + Recommendations. Audio should prioritize actionable feedback rather than reading every metric.

## 11. Execution vs lane reaction
Every shot begins from intent: `Feet → Launch → Arrows → Breakpoint → Entry`.

LaneSight must distinguish whether the bowler missed the intended shot or executed it but experienced changed reaction.

Internal classes can include: EXECUTED, EXECUTION_MISS, REACTION_CHANGE, MIXED, LOW_CONFIDENCE.

After a non-strike ask: **Did you hit your intended line?** Yes / No / Not sure.
- Yes: can contribute to lane evidence if release is comparable.
- No: exclude from lane-transition evidence; retain for execution coaching.
- Not sure: retain with reduced weighting.

Execution Coach tracks directional bias and variance. Systematic misses can justify execution adjustments; random scatter should favor consistency coaching rather than moving the target.

Lane Coach uses comparable well-executed shots to infer transition. It must be willing to say **No adjustment recommended yet**.

## 12. Recommendation learning
Track: `Observation → Recommendation → Bowler adjustment → Next shot(s) → Outcome → Recommendation success`.

This creates both a bowler feedback loop and a LaneSight learning loop.

## 13. Team Lane Management
With explicit teammate enrollment, LaneSight can understand how a team is collectively playing the pair.

Build a shared Team Lane Map using bowler, ball/configuration, intended line, actual trajectory, execution classification, timestamp and result. Estimate traffic zones and observed reaction changes. Team strategy should seek playable, repeatable alternatives and favorable lane development—not blindly minimize “degradation.”

Warmup can produce a team brief and individualized starting recommendations. Team invitations are a major organic growth loop.

## 14. External ecosystem
Strategic targets include USBC, LeaguePals, LaneTalk, center scoring systems and bowling sensors. Do not assume APIs or permissions. Use adapter interfaces and verify official access before promising integrations.

LaneSight should initially be the consumer intelligence layer over authoritative sources, not immediately replace them.

## 15. League management expansion
League Mode and League Management are separate.

After bowler/team traction, LaneSight Leagues can progressively add teams, rosters, schedules, lane assignments, handicaps/scratch formats, substitutes, absences, pre/post-bowls, position rounds, standings, communications, score ingestion and later dues/payments/prize-fund workflows.

Market-entry principle: do not lead with “replace your league software.” Create enough bowler pull that secretaries and centers have a reason to adopt LaneSight.

## 16. GTM
Initial target users: serious league bowlers, tournament bowlers and coaches.

Growth loop: `Free Shot Analyzer → Profile → Arsenal/Sensor → League Mode → Shareable Replay → Team Invite → Connected Records → Secretary/Center Pull`.

Do not lead with proprietary hardware, smart glasses, complicated onboarding or unverified partner promises.

## 17. Brand
Master brand: **LaneSight**. Preferred mark: **LS Monogram** with a lane/trajectory integrated into the S. The old eye concept is no longer the preferred master mark.

Current color direction:
- Midnight Navy #0B1320
- Lane Blue #007BFF
- Electric Blue #00D2FF
- Cool Gray #A7B0BE
- Ice White #F7F9FC

These are current concept colors; production accessibility and print values still need finalization.

## 18. Current stack direction
- iOS-first mobile experience
- web/debug and later admin tooling
- Python FastAPI / CV services
- OpenCV + PyTorch
- detector/tracker benchmark rather than premature lock-in
- Postgres/Supabase
- object storage
- async jobs
- Supabase Auth
- structured logging/model provenance
- native/service TTS
- adapter layers for sensors and external bowling/scoring systems

## 19. Data model anchors
User, BowlerProfile, BallModel, UserBall, BallConfiguration, SurfaceEvent, BallMaintenanceEvent, OilPattern, Session, SessionLane, LeagueSession, Shot, ShotIntent, UserShotFeedback, ShotClassification, VideoAsset, Calibration, TrajectoryPoint, Measurement, MeasurementSource, PinState, SensorDevice, SensorShot, Observation, Recommendation, RecommendationOutcome, TransitionState, SessionIdentity, UserMatchDecision, TeamLaneState, ExternalIdentity, ExternalDataConnection, League, LeagueSeason, Team, TeamMembership, ScoreRecord, MembershipRecord and ExternalMetric.

## 20. Validation
Use personal bowling video as Seed Dataset v1. Collect controlled fixed-camera shots and manually annotate a subset. Split data by session/center/bowler where possible and reserve a locked test set. Specto is a periodic high-quality benchmark, not a dependency.

## 21. Explicitly superseded framing
- LaneSight is **not** primarily a Meta smart-glasses app.
- POV is **not** the first measurement environment.
- Sensor fusion is **not** a late partnership-only feature.
- The eye logo is **not** the preferred master mark.
- Full league management is **not** the MVP.
- A missed-execution shot is **not** discarded from all coaching.

## 22. Canonical documents
- Product strategy PRD: `01_PRODUCT/LaneSight_PRD_Product_Strategy_v3.docx`
- Current build state: `00_CONTEXT/CURRENT_STATE.md`
- Decisions: `00_CONTEXT/DECISIONS.md`
- Detailed implementation docs: `03_ENGINEERING/`
